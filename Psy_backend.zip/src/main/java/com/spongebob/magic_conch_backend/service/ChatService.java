package com.spongebob.magic_conch_backend.service;

public interface ChatService {

    String callAiForOneReply(String prompt);
}
