package com.spongebob.magic_conch_backend.service.impl.chat.model;

public class GenerateResponse {
    private String generated_text;

    public GenerateResponse(){}
    public String getGenerated_text() {
        return generated_text;
    }

    public void setGenerated_text(String generated_text) {
        this.generated_text = generated_text;
    }
}
