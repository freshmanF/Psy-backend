package com.spongebob.magic_conch_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MagicConchBackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(MagicConchBackendApplication.class, args);
    }

}
